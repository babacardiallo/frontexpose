import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
 
export interface Slot { start: string; end: string; }
export interface Reservation { id: string; method: string; start: string; end: string; customer: string; }
 
@Injectable({ providedIn: 'root' })
export class ReservationService {
  private base = 'http://localhost:8080/api/v1';
 
  constructor(private http: HttpClient) {}

  methods(): Observable<string[]> {
    return this.http.get<string[]>(`${this.base}/delivery-methods`);
  }
 
  slots(method: string) {
    return this.http.get<Slot[]>(`${this.base}/slots?method=${method}`);
  }
 
  reserve(method: string, slot: Slot, customer: string) {
    return this.http.post<Reservation>(`${this.base}/reservations`, {
      method, slotStart: slot.start, slotEnd: slot.end, customer
    });
  }
}