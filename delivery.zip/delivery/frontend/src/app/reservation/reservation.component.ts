import { Component, signal } from '@angular/core';
import { ReservationService, Slot } from './service/reservation.service';

@Component({
  selector: 'app-reservation',
  imports: [],
  templateUrl: './reservation.component.html',
  styleUrl: './reservation.component.scss'
})
export class ReservationComponent{
  methods= signal<string[]>([]);
  slots = signal<Slot[]>([]);
  selectedMethod = signal<string>('');
  successMessage = signal<string>('');
  errorMessage = signal<string>('');
  showPopup = signal<boolean>(false);
  popupSlot = signal<Slot | null>(null);
  customerInput = signal<string>('');
 
  constructor(private reservationService: ReservationService) {}
 
  ngOnInit() {
    this.reservationService.methods().subscribe((m : any)=> {
      this.methods.set(m);      
      if(this.methods().length > 0){
        this.selectedMethod.set(m[0]);        
        this.reservationService.slots(m[0]).subscribe((s: any) => this.slots.set(s));
      }
    });
  }

 
  
  onMethod(target: EventTarget | null) {
    const value = (target as HTMLSelectElement).value;
    this.selectedMethod.set(value);
    this.reservationService.slots(value).subscribe((s: any) => this.slots.set(s));
  }

  openPopup(slot: Slot) {
    this.popupSlot.set(slot);
    this.customerInput.set('');
    this.showPopup.set(true);
  }

  closePopup() {
    this.showPopup.set(false);
  }
 
 
  confirmReservation() {
    const customer = this.customerInput().trim();
    if (!customer) {
      this.errorMessage.set("Veuillez entrer un identifiant client.");
      setTimeout(() => this.errorMessage.set(''), 4000);
      return;
    }

    const slot = this.popupSlot();
    if (!slot) return;

    this.reservationService.reserve(this.selectedMethod(), slot, customer).subscribe({
      next: (res: any) => {
        this.showPopup.set(false);
        this.errorMessage.set('');
        this.successMessage.set("Réservation confirmée ! ID : " + res.id);
        setTimeout(() => this.successMessage.set(''), 4000);
      },
      error: (err: any) => {
        this.showPopup.set(false);
        this.successMessage.set('');
        this.errorMessage.set(
          "Ce créneau est déjà réservé."
        );
        setTimeout(() => this.errorMessage.set(''), 4000);
      }
    });
  }
}
