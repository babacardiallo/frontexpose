import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ReservationComponent } from './reservation/reservation.component';

@Component({
  selector: 'app-root',
  imports: [ReservationComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'frontend';
}
