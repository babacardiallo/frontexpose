📘 Reservation System — README

🧱 1. Backend — Spring Boot (DDD)

    a) Java 21
    a) Spring Boot 3.5.7
    b) DDD
    c) Pas de base de données ni de sécurité, une application InMemoery

🚀 Description: Ce backend expose des APIs REST pour :

    1. récupérer les méthodes de réservation (DRIVE, LIVRAISON…)

    2. afficher les créneaux disponibles

    3. réserver un créneau

🚀 Compiler et lancer : mvn clean spring-boot:run

🚀 Endpoints

      - GET  /api/delivery-methods   : récupère la liste des méthodes de livraison disponibles
      - GET  /api/slots?method=DRIVE  : récupère les créneaux disponibles pour une méthode
      - POST /api/reservations   : Faire une réservation
            Body (json):

            {

               "method": "DRIVE",

               "slotStart": "2025-11-18T10:00:00",

               "slotEnd": "2025-11-18T11:00:00",

               "customer": "alice@example.com"

           }

🎨 2. Frontend — Angular 19 (Zone-Less + Signals)

🚀 Description: Frontend Angular 19 utilisant :

    a) Standalone Components

    b) Signals


🚀 Fonctionnalités:

     a) Sélection d’une méthode

     b) Affichage dynamique des créneaux

     c) Popup pour saisir l’identifiant

     d) Alertes stylées success / error

🚀 Installation et lancement:
  
     a) npm install
     b) npm start
 
