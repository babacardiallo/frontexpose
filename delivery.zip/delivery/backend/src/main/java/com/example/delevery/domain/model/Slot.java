package com.example.delevery.domain.model;

import java.time.LocalDateTime;

public record Slot(LocalDateTime start, LocalDateTime end) {
    public Slot {
        if (start == null || end == null) throw new IllegalArgumentException("La date de debut et de fin sont toutes obligatoires");
        if (!end.isAfter(start)) throw new IllegalArgumentException("La date de fin doit etre supérieur à la date de debut");
    }

}
