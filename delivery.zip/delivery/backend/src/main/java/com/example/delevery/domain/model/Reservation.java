package com.example.delevery.domain.model;

import java.util.UUID;

public record Reservation(UUID id,LivraisonMethod method,Slot slot, String customer) {}
