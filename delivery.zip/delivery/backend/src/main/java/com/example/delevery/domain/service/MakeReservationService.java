package com.example.delevery.domain.service;

import com.example.delevery.domain.model.LivraisonMethod;
import com.example.delevery.domain.model.Reservation;
import com.example.delevery.domain.model.Slot;
import com.example.delevery.domain.port.in.MakeReservationUseCase;
import com.example.delevery.domain.port.out.LoadTimeSlot;
import com.example.delevery.domain.port.out.SaveReservation;

import java.util.List;
import java.util.UUID;

public class MakeReservationService implements MakeReservationUseCase {

    private final LoadTimeSlot loadTimeSlot;
    private final SaveReservation saveReservation;

    public MakeReservationService(LoadTimeSlot loadTimeSlot, SaveReservation saveReservation) {
        this.loadTimeSlot = loadTimeSlot;
        this.saveReservation = saveReservation;
    }

    @Override
    public Reservation makeReservation(LivraisonMethod method, Slot slot, String customer) {
        List<Slot> availableSlots = loadTimeSlot.loadSlots(method);
        boolean exists = availableSlots.stream().anyMatch(s -> s.equals(slot));
        if (!exists) throw new IllegalArgumentException("Il n' y a pas de créneau disponible pour ce méthode de livraion " + method);
        boolean slotAlreadyReserved = saveReservation.findAll().stream()
                .anyMatch(r -> r.method().equals(method) && r.slot().equals(slot));
        if (slotAlreadyReserved) throw new IllegalStateException("Ce créneau est déjà réservé");
        Reservation r = new Reservation(UUID.randomUUID(), method, slot, customer);
        saveReservation.save(r);
        return r;
    }
}
