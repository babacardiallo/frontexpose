package com.example.delevery.adapter.in;

import com.example.delevery.domain.model.LivraisonMethod;
import com.example.delevery.domain.model.Reservation;
import com.example.delevery.domain.model.Slot;
import com.example.delevery.domain.port.in.MakeReservationUseCase;
import com.example.delevery.domain.port.out.LoadTimeSlot;
import com.example.delevery.domain.port.out.SaveReservation;
import com.example.delevery.domain.service.MakeReservationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin("*")
public class ReservationController {

    private final LoadTimeSlot loadTimeSlot;
    private final MakeReservationUseCase makeReservationUseCase;

    public ReservationController(LoadTimeSlot loadTimeSlot, SaveReservation saveReservation) {
        this.loadTimeSlot = loadTimeSlot;
        this.makeReservationUseCase = new MakeReservationService(loadTimeSlot, saveReservation);

    }

    @GetMapping("/delivery-methods")
    public List<String> methods() {
        return Arrays.stream(LivraisonMethod.values()).map(Enum::name).toList();
    }

    @GetMapping("/slots")
    public List<SlotDto> slots(@RequestParam("method") String method) {
        LivraisonMethod safeMethod = LivraisonMethod.valueOf(method.toUpperCase(Locale.ROOT));
        return loadTimeSlot.loadSlots(safeMethod).stream().map(SlotDto::from).toList();

    }

    @PostMapping("/reservations")
    public ResponseEntity<?> reserve(@RequestBody ReserveRequest req) {
        try {
            LivraisonMethod method = LivraisonMethod.valueOf(req.method().toUpperCase(Locale.ROOT));
            Slot slot = new Slot(LocalDateTime.parse(req.slotStart()), LocalDateTime.parse(req.slotEnd()));
            var reservation = makeReservationUseCase.makeReservation(method, slot, req.customer());
            return ResponseEntity.ok(ReservationDto.from(reservation));

        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (IllegalStateException e) {
            return ResponseEntity.status(409).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(500).body(Map.of("error", "internal"));

        }

    }


    public static record SlotDto(String start, String end) {
        static SlotDto from(Slot s) { return new SlotDto(s.start().toString(), s.end().toString()); }
    }
    public static record ReserveRequest(String method, String slotStart, String slotEnd, String customer) {}

    public static record ReservationDto(String id, String method, String start, String end, String customer) {
        static ReservationDto from(Reservation r) {
            return new ReservationDto(r.id().toString(), r.method().name(), r.slot().start().toString(), r.slot().end().toString(), r.customer());
        }
    }

}
