package com.example.delevery.domain.model;

public enum LivraisonMethod {
    DRIVE,
    DELIVERY,
    DELIVERY_TODAY,
    DELIVERY_ASP
}
