package com.example.delevery.domain.port.in;

import com.example.delevery.domain.model.LivraisonMethod;
import com.example.delevery.domain.model.Reservation;
import com.example.delevery.domain.model.Slot;

public interface MakeReservationUseCase {
    Reservation makeReservation(LivraisonMethod method, Slot slot, String customer);

}
