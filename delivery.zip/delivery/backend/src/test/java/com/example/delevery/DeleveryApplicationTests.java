package com.example.delevery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeleveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
